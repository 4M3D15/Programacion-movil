package com.example.practica_kotlin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
