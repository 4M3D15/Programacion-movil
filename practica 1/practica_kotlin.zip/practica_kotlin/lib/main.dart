import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:io';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MenuScreen(),
    );
  }
}

class MenuScreen extends StatefulWidget {
  @override
  _MenuScreenState createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  final TextEditingController _controller = TextEditingController();
  String _output = "";

  void _procesarOpcion(String opcion) {
    setState(() {
      switch (opcion) {
        case "1":
          _sumarNumeros();
          break;
        case "2":
          _ingresarNombre();
          break;
        case "3":
          _calcularTiempoVida();
          break;
        case "4":
          _output = "Saliendo del programa...";
          Future.delayed(Duration(seconds: 1), () {
            exit(0); // Cierra la aplicación
          });
          break;
        default:
          _output = "Opción no válida. Intente de nuevo.";
      }
      _controller.clear();
    });
  }

  void _sumarNumeros() {
    setState(() {
      _output = "Ingrese tres números separados por espacios:";
    });
  }

  void _ingresarNombre() {
    setState(() {
      _output = "Ingrese su nombre completo:";
    });
  }

  void _calcularTiempoVida() {
    setState(() {
      _output = "Ingrese su fecha de nacimiento (YYYY-MM-DD):";
    });
  }

  void _procesarEntrada(String entrada) {
    if (_output.contains("Ingrese tres números")) {
      List<String> numeros = entrada.split(" ");
      if (numeros.length == 3) {
        try {
          double suma = numeros.map((e) => double.parse(e)).reduce((a, b) => a + b);
          setState(() {
            _output = "La suma es: $suma";
          });
        } catch (e) {
          setState(() {
            _output = "Error: Ingrese solo números válidos.";
          });
        }
      } else {
        setState(() {
          _output = "Error: Ingrese exactamente tres números separados por espacios.";
        });
      }
    } else if (_output.contains("Ingrese su nombre completo")) {
      setState(() {
        _output = "Nombre ingresado: $entrada";
      });
    } else if (_output.contains("Ingrese su fecha de nacimiento")) {
      try {
        DateTime nacimiento = DateTime.parse(entrada);
        DateTime ahora = DateTime.now();
        Duration diferencia = ahora.difference(nacimiento);
        int dias = diferencia.inDays;
        int semanas = dias ~/ 7;
        int meses = dias ~/ 30;
        int horas = dias * 24;
        int minutos = horas * 60;
        int segundos = minutos * 60;
        setState(() {
          _output = "Has vivido: $meses meses, $semanas semanas, $dias días, $horas horas, $minutos minutos, $segundos segundos";
        });
      } catch (e) {
        setState(() {
          _output = "Error: Formato de fecha incorrecto. Use YYYY-MM-DD.";
        });
      }
    } else {
      _procesarOpcion(entrada);
    }
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Menú Principal")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Menú:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text("1: Sumar tres números\n2: Ingresar nombre completo\n3: Calcular tiempo de vida\n4: Salir"),
            TextField(
              controller: _controller,
              decoration: InputDecoration(labelText: "Ingrese una opción o dato"),
              onSubmitted: _procesarEntrada,
            ),
            SizedBox(height: 20),
            Text(_output, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

