package com.practica2botones
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// Actividad principal donde se muestra la interfaz gráfica
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyFirstScreen()
        }
    }
}

@Composable
fun MyFirstScreen() {
    // Estado para mostrar el mensaje cuando se presiona el botón
    var showMessage by remember { mutableStateOf(false) }

    // Diseño de la pantalla
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Botón que cambia el estado al presionarlo
        Button(onClick = { showMessage = true }) {
            Text(text = "Hola")
        }

        Spacer(modifier = Modifier.height(16.dp)) // Espaciado entre elementos

        // Se muestra el mensaje solo si showMessage es verdadero
        if (showMessage) {
            Text(text = "Bienvenido al mundo de las apps")
        }
    }
}
