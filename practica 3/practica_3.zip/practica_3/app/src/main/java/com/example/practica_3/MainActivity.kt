package com.example.practica_3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.practica_3.ui.theme.Practica_3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Practica_3Theme {
                MainScreen(onClose = { finish() })
            }
        }
    }
}

@Composable
fun MainScreen(onClose: () -> Unit) {
    val opciones = listOf("Regular", "Irregular", "En proceso", "Cierre")
    var selectedOption by remember { mutableStateOf("Selecciona una opción") }
    var checkboxChecked by remember { mutableStateOf(false) }
    var radioChecked by remember { mutableStateOf(false) }

    val showCheckbox = selectedOption == "Regular" || selectedOption == "Irregular"
    val showRadio = selectedOption == "Cierre"
    val showMessage = selectedOption == "En proceso"
    val showCloseButton =
        (selectedOption == "En proceso") || (showCheckbox && checkboxChecked) || (showRadio && radioChecked)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("", fontSize = 20.sp)

            CustomDropdownMenu(
                selected = selectedOption,
                options = opciones,
                onSelected = {
                    selectedOption = it
                    checkboxChecked = false
                    radioChecked = false
                }
            )

            if (showCheckbox) {
                CustomCheckbox(
                    checked = checkboxChecked,
                    onCheckedChange = { checkboxChecked = it }
                )
            }

            if (showRadio) {
                CustomRadioButton(
                    selected = radioChecked,
                    onClick = { radioChecked = !radioChecked }
                )
            }

            if (showMessage) {
                ErrorMessage()
            }

            if (showCloseButton) {
                CloseButton(onClick = onClose)
            }
        }
    }
}

@Composable
fun CustomDropdownMenu(
    selected: String,
    options: List<String>,
    onSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var buttonWidth by remember { mutableStateOf(0) }

    Box(contentAlignment = Alignment.Center) {
        Button(
            onClick = { expanded = true },
            modifier = Modifier
                .fillMaxWidth()
                .onGloballyPositioned {
                    buttonWidth = it.size.width
                },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3366CC)) // Azul accesible
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(selected, color = Color.White, fontSize = 18.sp)
                Icon(
                    imageVector = Icons.Filled.ArrowDropDown,
                    contentDescription = "Flecha hacia abajo",
                    tint = Color.White
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier
                .width(with(LocalDensity.current) { buttonWidth.toDp() })
        ) {
            options.forEach { label ->
                DropdownMenuItem(
                    text = { Text(label, fontSize = 18.sp) },
                    onClick = {
                        onSelected(label)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun CustomCheckbox(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Text("Acepto el reto", fontSize = 18.sp)
    }
}

@Composable
fun CustomRadioButton(selected: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text("Cierre del programa", fontSize = 18.sp)
    }
}

@Composable
fun ErrorMessage() {
    Text("Vuelve a intentar", color = Color(0xFFD32F2F), fontSize = 18.sp) // Rojo accesible
}

@Composable
fun CloseButton(onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)) // Verde accesible
    ) {
        Text("Cerrar", color = Color.White, fontSize = 18.sp)
    }
}
