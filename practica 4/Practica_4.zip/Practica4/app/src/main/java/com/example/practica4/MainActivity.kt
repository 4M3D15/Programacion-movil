package com.example.practica4

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 189, 40, 40) // Padding superior de ~5cm
            setBackgroundColor(Color.WHITE)
        }

        // Mensaje para el usuario
        val avisoMayusculas = TextView(this@MainActivity).apply {
            text = "ATENCION!!! El sistema convertirá automáticamente los datos a mayúsculas."
            setTextColor(Color.DKGRAY)
            textSize = 16f
            setPadding(0, 0, 0, 30)
        }
        layout.addView(avisoMayusculas)

        // Fondo redondeado
        fun fondoCampo(): GradientDrawable {
            return GradientDrawable().apply {
                setColor(Color.parseColor("#F5F5F5"))
                cornerRadius = 25f
                setStroke(2, Color.LTGRAY)
            }
        }

        // Campos de texto
        fun crearCampo(hint: String, maxLength: Int, inputType: Int): EditText {
            return EditText(this@MainActivity).apply {
                this.hint = hint
                background = fondoCampo()
                setPadding(30, 20, 30, 20)
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                this.inputType = inputType
                // Limitar a mayúsculas y longitud máxima
                filters = arrayOf(
                    InputFilter.AllCaps(),
                    InputFilter.LengthFilter(maxLength)
                )
            }
        }

        // Creación de campos
        val rfcField = crearCampo("RFC (13 caracteres)", 13, InputType.TYPE_CLASS_TEXT)
        val curpField = crearCampo("CURP (18 caracteres)", 18, InputType.TYPE_CLASS_TEXT)
        val nombreField = crearCampo("Nombre (máx. 20)", 20, InputType.TYPE_CLASS_TEXT)

        // Advertencias
        val rfcError = TextView(this@MainActivity).apply { setTextColor(Color.RED) }
        val curpError = TextView(this@MainActivity).apply { setTextColor(Color.RED) }
        val nombreAdvertencia = TextView(this@MainActivity).apply { setTextColor(Color.RED) }

        // Redondeo de los botones
        fun crearFondoBoton(color: Int): GradientDrawable {
            return GradientDrawable().apply {
                setColor(color)
                cornerRadius = 50f
            }
        }

        // Función estado boton
        fun actualizarEstadoBoton(boton: Button, habilitado: Boolean, colorActivo: Int) {
            boton.isEnabled = habilitado
            if (habilitado) {
                boton.background = crearFondoBoton(colorActivo)
                boton.alpha = 1.0f
            } else {
                boton.background = crearFondoBoton(Color.LTGRAY)
                boton.alpha = 0.5f
            }
        }

        // Estilo botones
        val botonLayoutParams = LinearLayout.LayoutParams(600, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = 30
            bottomMargin = 10
            gravity = android.view.Gravity.CENTER_HORIZONTAL
        }

        // Botón Aceptar
        val aceptarButton = Button(this@MainActivity).apply {
            text = "Aceptar"
            isEnabled = false
            background = crearFondoBoton(Color.LTGRAY)
            alpha = 0.5f
            setTextColor(Color.WHITE)
            layoutParams = botonLayoutParams
            setOnClickListener { finish() }
        }

        // Botón Cerrar
        val cerrarButton = Button(this@MainActivity).apply {
            text = "Cerrar"
            isEnabled = false
            background = crearFondoBoton(Color.LTGRAY)
            alpha = 0.5f
            setTextColor(Color.WHITE)
            layoutParams = botonLayoutParams
            setOnClickListener { finish() }
        }

        // Validaciones
        fun validarCampos() {
            val rfc = rfcField.text.toString().trim()
            val curp = curpField.text.toString().trim()
            val nombre = nombreField.text.toString()

            var error = false
            rfcError.text = ""
            curpError.text = ""
            nombreAdvertencia.text = ""

            if (rfc.isEmpty()) {
                rfcError.text = "Campo vacío"
                error = true
            } else if (rfc.length != 13) {
                rfcError.text = "Error de información"
                error = true
            }

            if (curp.isEmpty()) {
                curpError.text = "Campo vacío"
                error = true
            } else if (curp.length != 18) {
                curpError.text = "Error de información"
                error = true
            }

            if (nombre.length > 20) {
                nombreAdvertencia.text = "Advertencia: longitud mayor a 20 caracteres"
            }

            // Actualizar botones
            actualizarEstadoBoton(aceptarButton, !error, Color.parseColor("#4CAF50")) // Verde
            actualizarEstadoBoton(cerrarButton, !error, Color.parseColor("#FF5722")) // Rojo
        }

        val textWatcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = validarCampos()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }

        rfcField.addTextChangedListener(textWatcher)
        curpField.addTextChangedListener(textWatcher)
        nombreField.addTextChangedListener(textWatcher)

        layout.addView(rfcField)
        layout.addView(rfcError)
        layout.addView(curpField)
        layout.addView(curpError)
        layout.addView(nombreField)
        layout.addView(nombreAdvertencia)
        layout.addView(aceptarButton)
        layout.addView(cerrarButton)

        setContentView(layout)
    }
}