package com.example.practica_5

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.example.practica_5.ui.theme.Practica_5Theme

@OptIn(ExperimentalAnimationApi::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Practica_5Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF5F5F5)
                ) {
                    ImageLoaderUI()
                }
            }
        }
    }
}

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ImageLoaderUI() {
    val context = LocalContext.current
    var selectedOption by remember { mutableStateOf("Selecciona opción") }
    var expanded by remember { mutableStateOf(false) }
    var imagePainter by remember { mutableStateOf<BitmapPainter?>(null) }
    var imageUrl by remember { mutableStateOf("") }

    val options = listOf("URL", "Manual", "Repositorio")
    val manualLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            context.contentResolver.openInputStream(it)?.use { stream ->
                val bmp = BitmapFactory.decodeStream(stream)
                imagePainter = BitmapPainter(bmp.asImageBitmap())
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Text(
            "Cargar Imágenes",
            fontSize = 22.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF212121),
            modifier = Modifier.padding(bottom = 20.dp)
        )

        // Selector con animación
        val rotation by animateFloatAsState(
            targetValue = if (expanded) 180f else 0f,
            animationSpec = tween(250)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(Color.White)
                .clickable { expanded = !expanded }
                .padding(12.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(selectedOption, color = Color(0xFF424242))
                Icon(
                    Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    modifier = Modifier.rotate(rotation),
                    tint = Color(0xFF424242)
                )
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White)
            ) {
                options.forEach { option ->
                    Text(
                        option,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedOption = option
                                expanded = false
                                imagePainter = null
                                if (option == "Manual") manualLauncher.launch("image/*")
                            }
                            .padding(12.dp),
                        textAlign = TextAlign.Center,
                        color = Color(0xFF424242)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // URL Input
        AnimatedVisibility(
            visible = selectedOption == "URL",
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically()
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                OutlinedTextField(
                    value = imageUrl,
                    onValueChange = { imageUrl = it },
                    placeholder = { Text("https://...", color = Color(0xFF9E9E9E)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White,
                        focusedBorderColor = Color(0xFFBDBDBD),
                        unfocusedBorderColor = Color(0xFFE0E0E0)
                    ),
                    singleLine = true
                )
                MinimalButton("Cargar") {
                    Toast.makeText(context, "Cargando...", Toast.LENGTH_SHORT).show()
                    Glide.with(context)
                        .asBitmap()
                        .load(imageUrl)
                        .into(object : CustomTarget<Bitmap>() {
                            override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                                imagePainter = BitmapPainter(resource.asImageBitmap())
                            }

                            override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                }
            }
        }

        // Repositorio
        AnimatedVisibility(
            visible = selectedOption == "Repositorio",
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically()
        ) {
            Column {
                val urls = listOf(
                    "https://drive.google.com/uc?export=download&id=1c6MCzwYD3zeRi3gAXSv6fJB78MlcYfKU",
                    "https://drive.google.com/uc?export=download&id=1FqMujj-RC5UJ0YkQF73kR2iBilw4cjJc",
                    "https://drive.google.com/uc?export=download&id=1Ym6Ga2KP_EY3CcbmN-g_rhCxtnLQL7LU",
                    "https://drive.google.com/uc?export=download&id=1gwy5t1lFRJ9d0VUHGvNbYLL95z7-S1nn"
                )
                urls.forEachIndexed { i, url ->
                    MinimalButton("Imagen ${i + 1}") {
                        Toast.makeText(context, "Cargando ${i + 1}...", Toast.LENGTH_SHORT).show()
                        Glide.with(context)
                            .asBitmap()
                            .load(url)
                            .into(object : CustomTarget<Bitmap>() {
                                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                                    imagePainter = BitmapPainter(resource.asImageBitmap())
                                }

                                override fun onLoadCleared(placeholder: Drawable?) {}
                            })
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Imagen cargada
        AnimatedVisibility(
            visible = imagePainter != null,
            enter = fadeIn(tween(300)) + scaleIn(tween(300)),
            exit = fadeOut(tween(200))
        ) {
            imagePainter?.let {
                Image(
                    painter = it,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()  // Ocupa todo el ancho
                        .height(400.dp)  // Ajusta la altura para hacerla más grande
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .padding(16.dp)  // Puedes agregar un poco de espacio alrededor de la imagen
                )
            }
        }
    }
}

@Composable
fun MinimalButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}
