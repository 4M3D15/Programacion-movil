// build.gradle.kts (Nivel del Proyecto)

// build.gradle.kts (nivel raíz)
plugins {
    id("com.android.application") version "8.9.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.10" apply false
}


buildscript {
    repositories {
        google()
        mavenCentral()
    }

    dependencies {
        classpath("com.android.tools.build:gradle:8.9.2")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.8.10")
    }
}

allprojects {
}

task<Delete>("clean") {
    delete(rootProject.buildDir)
}